import { Pessoa } from './pessoa';

describe('Pessoa', () => {
  it('should create an instance', () => {
    expect(new Pessoa()).toBeTruthy();
  });
});
