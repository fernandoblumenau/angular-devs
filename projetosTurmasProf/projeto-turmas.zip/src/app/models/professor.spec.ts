import { Professor } from './professor';

describe('Professor', () => {
  it('should create an instance', () => {
    expect(new Professor()).toBeTruthy();
  });
});
