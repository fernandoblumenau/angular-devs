import { Pessoa } from './pessoa';
export class Aluno {
  id?: number;
  ano?: number;
  turma?: string;
  pessoa?: Pessoa;
}
