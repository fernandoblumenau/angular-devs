export class Pessoa {
  id?: number;
  nome?: string;
  idade?: number;
  endereco?: string;
  sexo?: string;
}
