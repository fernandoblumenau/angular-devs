import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pessoa-save',
  templateUrl: './pessoa-save.component.html',
  styleUrls: ['./pessoa-save.component.scss']
})
export class PessoaSaveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
